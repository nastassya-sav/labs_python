For the 1-st lab, to input data from a file you need to make "file.txt" in "folder_rout" & enter an array in this file in such way: 1 2 3 4 5 
& then enter the borders in program while processing
 