import math

def main():
    inCorrectInput = True  # переменная, отвечающая за корректность
                           # введенных данных
    choose = 0  # переменная, отвечающая за выбор пользователя
    while inCorrectInput:
        try:
            choose = int(input('0. Input data from file\n1. '
                               'Input data from keyboard\n'))
            inCorrectInput = False  # когда ввели int
        except ValueError:
            inCorrectInput = True
            print('Input integer number, please')
        if choose != 0 and choose != 1:
            print('Number must be 0 or 1')
            inCorrectInput = True
    arr = []
    if choose == 1:
        inCorrectInput = True
        while inCorrectInput:
            try:
                n = int(input('Input size of array (has to be positive): '))
                arr = [int(input('Input integer number ')) for i in range(n)]
                inCorrectInput = False
                if n <= 0:
                    inCorrectInput = True
            except ValueError:
                inCorrectInput = True
                print('Mistake. Input integer numbers, please')
    else:
        f = open('lab_1.txt', 'r')  # открываем текстовый файл в режиме
                                    # чтения (read)
        for line in f:  # проходимся по строкам
            arrayWithNumbers = line.split()  # разбивает строку на числа в
                                             #  соответствии с пробелами
            for i in range(arrayWithNumbers.__len__()):
                arr.append(int(arrayWithNumbers[i]))  # по одному добавляем
                                                      # числа в массив
    n = arr.__len__()
    print(arr)
    # длина блока
    length = math.ceil(math.sqrt(n))
    # количество блоков
    count = n // length  # целочисленное деление
    if count * length != n:  # если массив не идеально разделился на блоки
        count += 1  # добавляем кривой блок
    # print(count)
    # массив сумм
    arrSum = []
    tempSum = 0
    for i in range(n):
        tempSum += arr[i]
        # проверка на то, кончился ли блок
        if i % length == length - 1:
            arrSum.append(tempSum)
            tempSum = 0
        # если не конец блока, но последний элемент массива
        elif i == n - 1:
            arrSum.append(tempSum)
    left = 0
    right = 0
    inCorrectInput = True
    while inCorrectInput:
        try:
            left = int(input('Input left bound ')) - 1
            right = int(input('Input right bound ')) - 1
            inCorrectInput = False
            if left < 0 or right < 0 or left >= n or right >= n:
                inCorrectInput = True
                print('Input numbers between 1 and array size')
            if left > right:
                left, right = right, left
        except ValueError:
            inCorrectInput = True
            print('Mistake. Input integer numbers, please')
    # номер блока для правой и левой границ
    blockLeft = left // length
    blockRight = right // length
    result = 0
    # когда между ними нет блоков
    if blockRight - blockLeft < 2:
        # range не включает верхнюю границу, просто сумма от l до r
        for k in range(left, right + 1):
            result += arr[k]
    else:
        # суммируем со следующего блока, не забывая, что верхняя
        # граница не включается,
        # если между ними есть блоки, то суммируем их
        for k in range(blockLeft + 1, blockRight):
            result += arrSum[k]
        # (blockLeft + 1) * length-позиция 1 элемента следующего
        # блока(не включается)-
        # считаем хвостики(левый хвостик)
        for k in range(left, (blockLeft + 1) * length):
            result += arr[k]
        # blockRight * length- 1 элемент блока, содержащего
        # right(правый хвостик)
        for k in range(blockRight * length, right + 1):
            result += arr[k]
    print(result)

if __name__ == "__main__":
  main()
